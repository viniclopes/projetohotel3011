package hotel.entidades;

public class Promocoes {
	private double valorDesconto;
	private String codigo_desconto;
	

	
	public double getValorDesconto() {
		return valorDesconto;
	}
	public void setValorDesconto(double valorDesconto) {
		this.valorDesconto = valorDesconto;
	}
	public String getCodigo_desconto() {
		return codigo_desconto;
	}
	public void setCodigo_desconto(String codigo_desconto) {
		this.codigo_desconto = codigo_desconto;
	}
	
}
