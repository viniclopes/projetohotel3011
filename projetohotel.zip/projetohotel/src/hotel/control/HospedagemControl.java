package hotel.control;

import java.util.List;

import hotel.dao.ClienteDAO;
import hotel.dao.QuartoDAO;
import hotel.entidades.Cliente;
import hotel.entidades.Quarto;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class HospedagemControl {
	private ObservableList<Cliente> lista = FXCollections.observableArrayList();
	private ClienteDAO cDAO = new ClienteDAO();
	
	public void manterCliente(Cliente q) {
		cDAO.adicionar(q);
		atualizarTabela();
	}

	public void buscarCliente(String CPF) {
		List<Cliente> resultado = cDAO.buscarCliente(CPF);
		lista.clear();
		lista.addAll(resultado);
	}

	public ObservableList<Cliente> getLista() {
		return lista;
	}

	public void alterarCliente(Cliente clienteselect, String cpf) {
		cDAO.atualizar(clienteselect,cpf);
	}

	public void atualizarTabela() {
		lista.clear();
		List<Cliente> resultado = cDAO.atualizarTabelas();
		lista.addAll(resultado);
	}

	public void apagar(String cpf) {
		cDAO.apagar(cpf);
	}
	
	private ObservableList<Quarto> Lista = FXCollections.observableArrayList();
	private QuartoDAO qDAO = new QuartoDAO();

	
	public ObservableList<Quarto> getlista() {
		return Lista;
	}

	public void adicionar(Quarto quarto) {
		qDAO.adicionar(quarto);
		atualizarTabela();
	}
	
	public void Apagar(String numero) {
		qDAO.apagar(numero);
	}
	
	public void alterarQuarto(Quarto quartoselect, String numero) {
		qDAO.atualizar(quartoselect,numero);
	}

	public void AtualizarTabela() {
		Lista.clear();
		List<Quarto> resultado = qDAO.atualizarTabelas();
		Lista.addAll(resultado);
	}
	
	public void buscaQuarto(String numero) {
		List<Quarto> resultado = qDAO.buscarQuarto(numero);
		Lista.clear();
		Lista.addAll(resultado);
	}

}
