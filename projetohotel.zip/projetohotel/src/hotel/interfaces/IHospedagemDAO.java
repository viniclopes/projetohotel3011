package hotel.interfaces;

import java.util.List;

import hotel.entidades.Cliente;
import hotel.entidades.Quarto;

public interface IHospedagemDAO {
	void adicionar(Cliente cliente);
	List<Cliente> buscarCliente(String codigo);
	void apagar(String codigo);
	void atualizar(Cliente cliente, String codigo);
	void adicionar(Quarto quarto);
	List<Quarto> buscarQuarto(String numero);
		void atualizar(Quarto Quarto, String numero);
}



