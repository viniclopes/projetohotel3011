package hotel.interfaces;

import javafx.scene.layout.Pane;

public interface BoundaryContent extends AssinanteExecutor{
	
	public Pane gerarTela();

}
