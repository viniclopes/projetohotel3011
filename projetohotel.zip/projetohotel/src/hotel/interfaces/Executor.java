package hotel.interfaces;

public interface Executor {
	void executar(String cmd);
}
