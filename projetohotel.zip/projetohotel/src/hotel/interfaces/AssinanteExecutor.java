package hotel.interfaces;

public interface AssinanteExecutor {
	void setExecutor(Executor e);
	Executor getExecutor();

}
